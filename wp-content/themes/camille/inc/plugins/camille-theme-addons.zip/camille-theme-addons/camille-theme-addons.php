<?php
/*
Plugin Name: Camille Theme Addons
Plugin URI: http://creanncy.com/
Description: Demo data, Post/Page options and other additional theme features
Author: Creanncy
Version: 2.1
Author URI: http://creanncy.com/
Text Domain: camille-cpt
License: General Public License
*/

// Define current WordPress version constant
define( 'camille_CPT_WP_VERSION', get_bloginfo( 'version' ) );

//load translated strings
add_action( 'init', 'camille_cpt_load_textdomain' );

//load init
add_action( 'init', 'camille_cpt_init' );

//flush rewrite rules on deactivation
register_deactivation_hook( __FILE__, 'camille_cpt_deactivation' );

function camille_cpt_deactivation() {
	// Clear the permalinks to remove our post type's rules
	flush_rewrite_rules();
}

function camille_cpt_load_textdomain() {
	load_plugin_textdomain( 'camille_cpt_plugin', false, basename( dirname( __FILE__ ) ) . '/languages' );
}

function camille_cpt_init() {
	global $pagenow;

	// Allow shortcodes in widgets
	add_filter('widget_text', 'do_shortcode');
	add_filter('widget_camille_text', 'do_shortcode');

	if (( $pagenow !== 'admin-ajax.php' ) && (is_admin())) {
		require plugin_dir_path( __FILE__ ).'inc/oneclick-demo-import/init.php';
	}
}

// Theme Shortcodes
function creanncy_shortcode_social_buttons($atts, $sc_content = null) {

	ob_start();

	camille_social_show();

	$sc_content = ob_get_contents();
	ob_end_clean();
	return $sc_content;
}

add_shortcode("creanncy_social_buttons", "creanncy_shortcode_social_buttons");

/**
*	Custom User social profiles
*/
function camille_add_to_author_profile( $contactmethods ) {

    $social_array = array('facebook' => 'Facebook', 'twitter' => 'Twitter', 'vk' => 'Vkontakte', 'google-plus' => 'Google Plus', 'behance' => 'Behance', 'linkedin' => 'LinkedIn', 'pinterest' => 'Pinterest', 'deviantart' => 'DeviantArt', 'dribbble' => 'Dribbble',  'flickr' => 'Flickr', 'instagram' => 'Instagram', 'skype' => 'Skype', 'tumblr' => 'Tumblr', 'twitch' => 'Twitch', 'vimeo-square' => 'Vimeo', 'youtube' => 'Youtube');

    foreach ($social_array as $social_key => $social_value) {
        # code...
        $contactmethods[$social_key.'_profile'] = $social_value.' Profile URL';
    }

    return $contactmethods;
}
add_filter( 'user_contactmethods', 'camille_add_to_author_profile', 10, 1);

/**
*	Social share links function
*/
function camille_social_share_links() {

	$post_image_data = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID () ), 'camille-blog-thumb');

	if(has_post_thumbnail( get_the_ID () )) {
	    $post_image = $post_image_data[0];
	} else {
		$post_image = '';
	}
	?>
	<div class="post-social-wrapper">
	<div class="post-social-title show-social-share">
			<a><i class="fa fa-share-alt"></i></a></div><div class="post-social">
			<a title="<?php esc_html_e("Share this", 'camille'); ?>" href="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>" class="facebook-share"> <i class="fa fa-facebook"></i></a><a title="<?php esc_html_e("Tweet this", 'camille'); ?>" href="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>" class="twitter-share"> <i class="fa fa-twitter"></i></a><a title="<?php esc_html_e("Share with Google Plus", 'camille'); ?>" href="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>" class="googleplus-share"> <i class="fa fa-google-plus"></i></a><a title="<?php esc_html_e("Pin this", 'camille'); ?>" href="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>" data-image="<?php echo esc_attr($post_image); ?>" class="pinterest-share"> <i class="fa fa-pinterest"></i></a>
		</div>
		<div class="clear"></div>
	</div>
	<?php
}

add_action('camille_social_share', 'camille_social_share_links');

/**
*	Posts views count
*/
function camille_getPostViews($postID){
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return 0;
    }
    return $count;
}

function camille_setPostViews() {

    global $post;
    $postID = $post->ID;

    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
add_action('camille_set_post_views', 'camille_setPostViews');

/**
*	Posts views display
*/
function camille_post_views_display($custompost = '') {

	global $post;

	if($custompost !== '' ) {
		$post = $custompost;
	}

	$post_views = camille_getPostViews($post->ID);

	if($post_views < 1) {
	    $post_views = 0;
	}

    echo '<div class="views-count" title="'.esc_html__('Post views', 'camille-ta').'"><i class="fa fa-eye"></i>'.esc_html($post_views).'</div>';

}
add_action('camille_post_views', 'camille_post_views_display');

// Theme metaboxes
require plugin_dir_path( __FILE__ ).'inc/theme-metaboxes.php';

// Theme widgets
require plugin_dir_path( __FILE__ ).'inc/theme-widgets.php';
